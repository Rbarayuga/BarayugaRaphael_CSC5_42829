/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   main.cpp
 * Author: Raphael M.B. Barayuga
 * Purpose: Homework
 * Created on February 29, 2016, 2:44 AM
 */

//System Libraries
#include <iostream>

using namespace std;

/*
 //User libraries
 //Global COnstant
 */
int main(int argc, char** argv) {
    //Declare Variables
    int land, sqft , acres;
    sqft = 43560; //square feet per acre
    land = 391876;
    
   //Calculate acres in land
    acres = land / sqft ;
    
   //Display amount of acres
    cout << "there are " << acres << " acres " << endl;
    
    //Exit Stage Right
    return 0;
}

