/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   main.cpp
 * Author: Raphael M.B. Barayuga
 * Purpose: homework
 * Created on February 29, 2016, 3:55 AM
 */

//System Libraries
#include <iostream>

using namespace std;

/*
//User Libraries
//Global Constants
 */
int main(int argc, char** argv) {
   //Declare Variables
    float sales, percent, ecd;
    sales = 8600000;
    percent = 0.58;
   
  //Calculate East Coast Division generation
    ecd = sales * percent;
    
    //Display ECD generation 
    cout << " East Coast division will generate " << ecd << endl;
    
    //Exit Stage right
    
    return 0;
}

