/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   main.cpp
 * Author: Raphael M.B. Barayuga
 * Purpose: Homework
 * Created on February 29, 2016, 1:12 AM
 */

//System Libraries
#include <iostream>

using namespace std;

/*
 //User Libraries 
 //Global Constants
 */
int main(int argc, char** argv) {
    //Declare variables
    
    int car, gas, miles;
    gas = 15;
    miles = 375;

    
//Calculate MPG
car = miles / gas;
    
// Display MPG
cout << " MPG is " << car << endl;           
 
//Exit Stage Right

    return 0;
}

