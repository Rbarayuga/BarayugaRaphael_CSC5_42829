/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   main.cpp
 * Author: Raphael M.B. Barayuga
 * Purpose: Homework
 * Created on February 28, 2016, 11:53 PM
 */

//System Libraries
#include <iostream>
#include <iomanip>

using namespace std;

/*
//User Libraries
//Global Constants
 */
int main(int argc, char** argv) {
//Declare Variables
    float totsale, item1, item2, item3, item4, item5, statax, subtot, totax;
        item1 = 15.95; 
        item2 = 24.95;
        item3 = 6.95;
        item4 = 12.95;
        item5 = 3.95;
        statax = 0.07;
        subtot;
        totax;

//Calculate Subtotal of Sale
subtot = item1 + item2 + item3 +item4 + item5;

//Calculate sales tax
totax = subtot * statax;

//Amount of Total sale 
totsale = subtot + totax;

//Display each Variable price       
cout << " Item Price $ " << item1 << endl;
cout << " Item Price $ " << item2 << endl; 
cout << " Item Price $ " << item3 << endl; 
cout << " Item Price $ " << item4 << endl; 
cout << " Item Price $ " << item5 << endl; 

//Display subtotal
cout << " Subtotal $ " << subtot << endl; 

//Display Sales tax
cout << " Amount of sales tax $ " <<  fixed << setprecision(2) <<
 totax << endl; 

//Display Total 
cout << " Total $ " << totsale << endl; 

//Exit Stage Right

    return 0;
}

