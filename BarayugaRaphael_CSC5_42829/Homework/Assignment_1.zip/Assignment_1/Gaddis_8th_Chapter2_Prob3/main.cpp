/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   main.cpp
 * Author: Raphael M.B. Barayuga
 * Purpose: Homework
 * Created on February 29, 2016, 1:42 AM
 */

//System Libraries
#include <iostream>

using namespace std;

/*
//User Libraries
//Global Constants
 */
int main(int argc, char** argv) {
    
    float totax, countax, statax, bothtax;
        short purch = 95;
        countax = 0.04;
        statax = 0.02;
        bothtax;
       
// Calculation of total taxes
bothtax = countax + statax;
    
//Calculation of both taxes
totax = bothtax * purch;

//Display of total 
cout << " Total tax is $ " << totax << endl;
    
//Exit Stage Right

    return 0;
}

