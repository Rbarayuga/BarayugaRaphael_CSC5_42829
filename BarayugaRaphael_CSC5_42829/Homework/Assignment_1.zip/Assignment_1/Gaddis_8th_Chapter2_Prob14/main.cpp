/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   main.cpp
 * Author: Raphael M.B. Barayuga
 * Purpose: Homework
 * Created on February 28, 2016, 10:13  PM
 */

//System Libraries
#include <iostream>
#include <string>
using namespace std;

/*
//User Libraries
//Global Constant
 */

int main(int argc, char** argv) {
 //Declare Variables    
    string name, address, major;
    name = "Raphael Barayuga";
    address = "15181 Van Buren Blvd Riverside CA 92504";
    major = "CIS";
    long phone = 8087543470;
 
   //Display info
    cout << "Name: " << name << endl << "Address: " << address << endl
    << "Phone: " << phone << endl << "Major: " << major << endl;
   
    //Exit stage right
   
    return 0;        
} 
