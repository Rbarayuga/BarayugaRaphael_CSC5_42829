/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   main.cpp
 * Author: Raphael M.B. Barayuga
 * Purpose: Homework
 * Created on February 29, 2016, 1:27 AM
 */

//System Libraries
#include <iostream>

using namespace std;
/*
//User Libraries
//Global Constants 
 */

int main(int argc, char** argv) {
       //Declare Variables 
        short  car; 
        float towgal; 
        short tmpg; 
        short higal;
        float hmpg;
        
            car = 20; //gallons in car
            
            towgal; // gallon in town
            
            tmpg = 23.5; //town MPG
            
            higal; // gallons in town
            
            hmpg = 28.9; // highway MPG
            
    
    //Calculate distance for townMPG
    towgal = car * tmpg;
    
    //Calculate distance for highwayMPG
    higal = car * hmpg;
    
    //Display for town
    cout << " Miles in town is " <<  towgal  << endl;
    
    //Display for highway
    cout << " Miles on highway is " <<  higal  << endl;        
    
    //Exit Stage Right
    return 0;
}

