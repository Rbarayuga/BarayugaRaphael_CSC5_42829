/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   main.cpp
 * Author: Raphael M.B. Barayuga
 * Purpose: Homework
 * Created on February 29, 2016, 4:06 AM
 */

//System Libraries
#include <iostream>

using namespace std;

/*
 //User Libraries
 //Global Constants
 */
int main(int argc, char** argv) {        
  //Display size of a character
    
   cout << "the size of a char is " << sizeof(char);
   cout << " bytes. "<< endl;
   
  //Display size of a int
           
   cout << "the size of a int is " << sizeof(int);
   cout << " bytes. "<< endl;
   
  //Display size of a Float
   
   cout << "the size of a float is " << sizeof(float);
   cout << " bytes. "<< endl;
    
 //Display size of a double 
   
   cout << "the size of a double is " << sizeof(double);
   cout << " bytes. "<< endl;
   
   //Exit Stage Right
    return 0;
}

